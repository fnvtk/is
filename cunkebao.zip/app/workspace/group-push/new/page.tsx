"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, ArrowRight, Check, Search, X, Clock, Users, Smartphone, User } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// 步骤定义
const steps = ["基本信息", "选择好友"]

// 模拟设备数据
const mockDevices = [
  { id: "1", name: "设备1 (iPhone 13)", online: true },
  { id: "2", name: "设备2 (华为 P40)", online: true },
  { id: "3", name: "设备3 (小米 12)", online: false },
  { id: "4", name: "设备4 (OPPO Find X3)", online: true },
]

// 模拟标签数据
const mockTags = [
  { id: "1", name: "重要客户" },
  { id: "2", name: "潜在客户" },
  { id: "3", name: "合作伙伴" },
  { id: "4", name: "供应商" },
  { id: "5", name: "同事" },
]

// 模拟地区数据
const mockRegions = [
  { id: "1", name: "北京" },
  { id: "2", name: "上海" },
  { id: "3", name: "广州" },
  { id: "4", name: "深圳" },
  { id: "5", name: "杭州" },
]

// 模拟好友数据
const mockFriends = [
  {
    id: "1",
    deviceId: "1",
    name: "张三",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["重要客户"],
    region: "北京",
    type: "personal",
  },
  {
    id: "2",
    deviceId: "1",
    name: "李四",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["合作伙伴"],
    region: "上海",
    type: "personal",
  },
  {
    id: "3",
    deviceId: "1",
    name: "王五",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["供应商"],
    region: "广州",
    type: "personal",
  },
  {
    id: "4",
    deviceId: "2",
    name: "赵六",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["同事"],
    region: "深圳",
    type: "personal",
  },
  {
    id: "5",
    deviceId: "2",
    name: "钱七",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["重要客户"],
    region: "北京",
    type: "personal",
  },
  {
    id: "6",
    deviceId: "2",
    name: "产品交流群",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["潜在客户"],
    region: "上海",
    type: "group",
    memberCount: 18,
  },
  {
    id: "7",
    deviceId: "3",
    name: "技术讨论群",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["合作伙伴"],
    region: "广州",
    type: "group",
    memberCount: 25,
  },
  {
    id: "8",
    deviceId: "3",
    name: "市场部群",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["供应商"],
    region: "深圳",
    type: "group",
    memberCount: 12,
  },
  {
    id: "9",
    deviceId: "4",
    name: "客户服务群",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["同事"],
    region: "杭州",
    type: "group",
    memberCount: 32,
  },
  {
    id: "10",
    deviceId: "4",
    name: "行业交流群",
    avatar: "/placeholder.svg?height=40&width=40",
    tags: ["重要客户"],
    region: "北京",
    type: "group",
    memberCount: 45,
  },
]

// 消息编辑器组件
function MessageEditor({ value, onChange }) {
  const [text, setText] = useState(value.text || "")
  const [images, setImages] = useState(value.images || [])

  const handleTextChange = (e) => {
    setText(e.target.value)
    onChange({ ...value, text: e.target.value })
  }

  const handleImageUpload = (e) => {
    // 这里只是模拟上传，实际应用中需要处理文件上传
    const newImages = [...images, { id: Date.now(), url: "/placeholder.svg?height=100&width=100" }]
    setImages(newImages)
    onChange({ ...value, images: newImages })
  }

  const removeImage = (id) => {
    const newImages = images.filter((img) => img.id !== id)
    setImages(newImages)
    onChange({ ...value, images: newImages })
  }

  return (
    <div className="space-y-4">
      <div>
        <textarea
          className="w-full min-h-[120px] p-3 border rounded-md"
          placeholder="请输入消息内容..."
          value={text}
          onChange={handleTextChange}
        />
      </div>

      {images.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {images.map((img) => (
            <div key={img.id} className="relative">
              <img src={img.url || "/placeholder.svg"} alt="上传图片" className="w-20 h-20 object-cover rounded-md" />
              <button
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center"
                onClick={() => removeImage(img.id)}
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div>
        <Button type="button" variant="outline" onClick={handleImageUpload}>
          添加图片
        </Button>
      </div>
    </div>
  )
}

// 步骤指示器组件
function StepIndicator({ steps, currentStep }) {
  return (
    <div className="w-full mb-6">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center">
            <div
              className={`flex items-center justify-center w-8 h-8 rounded-full ${
                index <= currentStep ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-500"
              }`}
            >
              {index + 1}
            </div>
            <div className={`ml-2 ${index <= currentStep ? "text-blue-500 font-medium" : "text-gray-500"}`}>{step}</div>
            {index < steps.length - 1 && (
              <div className={`w-16 h-1 mx-2 ${index < currentStep ? "bg-blue-500" : "bg-gray-200"}`} />
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default function NewMessagePushPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(0)

  // 表单状态
  const [taskName, setTaskName] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")
  const [messageContent, setMessageContent] = useState({
    text: "",
    images: [],
  })
  const [selectedDevices, setSelectedDevices] = useState([])
  const [selectedFriends, setSelectedFriends] = useState([])

  // 筛选状态
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTag, setSelectedTag] = useState("all")
  const [selectedRegion, setSelectedRegion] = useState("all")
  const [contactType, setContactType] = useState("all") // 'all', 'personal', 'group'

  // 根据选择的设备、搜索词和筛选条件过滤好友
  const filteredFriends = mockFriends.filter((friend) => {
    // 如果没有选择设备，不显示任何好友
    if (selectedDevices.length === 0) return false

    // 只显示选中设备的好友
    const deviceMatch = selectedDevices.includes(friend.deviceId)

    // 搜索过滤
    const searchMatch = searchTerm === "" || friend.name.toLowerCase().includes(searchTerm.toLowerCase())

    // 标签过滤
    const tagMatch = selectedTag === "all" || friend.tags.includes(selectedTag)

    // 地区过滤
    const regionMatch = selectedRegion === "all" || friend.region === selectedRegion

    // 联系人类型过滤
    const typeMatch = contactType === "all" || friend.type === contactType

    return deviceMatch && searchMatch && tagMatch && regionMatch && typeMatch
  })

  const handleNext = () => {
    if (currentStep === 0) {
      // 验证第一步
      if (!taskName.trim()) {
        toast({
          title: "请输入任务名称",
          variant: "destructive",
        })
        return
      }

      if (!messageContent.text && messageContent.images.length === 0) {
        toast({
          title: "请添加至少一种消息内容",
          variant: "destructive",
        })
        return
      }
    }

    setCurrentStep((prev) => prev + 1)
  }

  const handlePrevious = () => {
    setCurrentStep((prev) => prev - 1)
  }

  const handleSubmit = () => {
    if (selectedDevices.length === 0) {
      toast({
        title: "请选择至少一个设备",
        variant: "destructive",
      })
      return
    }

    if (selectedFriends.length === 0) {
      toast({
        title: "请选择至少一个好友",
        variant: "destructive",
      })
      return
    }

    // 模拟提交
    toast({
      title: "推送任务创建成功",
      description: `已创建推送任务 "${taskName}"`,
    })

    // 跳转回列表页
    router.push("/workspace/group-push")
  }

  const toggleFriendSelection = (friendId) => {
    setSelectedFriends((prev) => {
      if (prev.includes(friendId)) {
        return prev.filter((id) => id !== friendId)
      } else {
        return [...prev, friendId]
      }
    })
  }

  const selectAllFriends = () => {
    setSelectedFriends(filteredFriends.map((friend) => friend.id))
  }

  const deselectAllFriends = () => {
    setSelectedFriends([])
  }

  return (
    <div className="container mx-auto py-6">
      {/* 顶部导航栏 */}
      <div className="flex items-center justify-between mb-6 relative">
        <Button variant="ghost" size="icon" onClick={() => router.push("/workspace/group-push")} className="mr-auto">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold absolute left-1/2 transform -translate-x-1/2">新建推送</h1>
        <div className="w-10"></div> {/* 占位元素，保持标题居中 */}
      </div>

      {/* 步骤指示器 */}
      <StepIndicator currentStep={currentStep} steps={steps} />

      <Card>
        <CardContent className="pt-6">
          {currentStep === 0 ? (
            <div className="space-y-6">
              <div>
                <Label htmlFor="task-name">任务名称</Label>
                <Input
                  id="task-name"
                  placeholder="请输入任务名称"
                  value={taskName}
                  onChange={(e) => setTaskName(e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="scheduled-time">推送时间</Label>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-gray-500" />
                  <Input
                    id="scheduled-time"
                    type="datetime-local"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-1">留空表示立即推送</p>
              </div>

              <div>
                <Label>消息内容</Label>
                <MessageEditor value={messageContent} onChange={setMessageContent} />
              </div>

              <div className="flex justify-end">
                <Button onClick={handleNext}>
                  下一步
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* 设备选择（下拉框） */}
              <div>
                <Label htmlFor="device-select">选择设备</Label>
                <Select
                  onValueChange={(value) => {
                    // 如果选择了"all"，则选择所有在线设备
                    if (value === "all") {
                      setSelectedDevices(mockDevices.filter((d) => d.online).map((d) => d.id))
                    } else {
                      // 否则，切换单个设备的选择状态
                      setSelectedDevices((prev) => {
                        if (prev.includes(value)) {
                          return prev.filter((id) => id !== value)
                        } else {
                          return [...prev, value]
                        }
                      })
                    }
                  }}
                >
                  <SelectTrigger id="device-select" className="w-full">
                    <SelectValue placeholder="请选择设备" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectItem value="all">全部在线设备</SelectItem>
                      {mockDevices.map((device) => (
                        <SelectItem key={device.id} value={device.id} disabled={!device.online}>
                          {device.name} {!device.online && "(离线)"}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>

                {/* 已选设备展示 */}
                {selectedDevices.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedDevices.map((deviceId) => {
                      const device = mockDevices.find((d) => d.id === deviceId)
                      return (
                        <Badge key={deviceId} variant="secondary" className="flex items-center gap-1">
                          <Smartphone className="h-3 w-3" />
                          {device?.name}
                          <button
                            className="ml-1 hover:bg-gray-200 rounded-full"
                            onClick={() => setSelectedDevices((prev) => prev.filter((id) => id !== deviceId))}
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      )
                    })}
                  </div>
                )}
              </div>

              {/* 只有在选择了设备后才显示好友筛选和列表 */}
              {selectedDevices.length > 0 ? (
                <>
                  {/* 好友筛选 */}
                  <div className="space-y-4">
                    <div className="flex flex-wrap gap-3">
                      {/* 搜索框 */}
                      <div className="flex-1 min-w-[200px]">
                        <Label htmlFor="search-friends">搜索</Label>
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                          <Input
                            id="search-friends"
                            placeholder="输入名称搜索"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-9"
                          />
                        </div>
                      </div>

                      {/* 联系人类型筛选 */}
                      <div className="w-40">
                        <Label htmlFor="contact-type">联系人类型</Label>
                        <Select value={contactType} onValueChange={setContactType}>
                          <SelectTrigger id="contact-type">
                            <SelectValue placeholder="选择类型" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">全部</SelectItem>
                            <SelectItem value="personal">个人微信</SelectItem>
                            <SelectItem value="group">微信群</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      {/* 标签筛选 */}
                      <div className="w-40">
                        <Label htmlFor="tag-filter">标签筛选</Label>
                        <Select value={selectedTag} onValueChange={setSelectedTag}>
                          <SelectTrigger id="tag-filter">
                            <SelectValue placeholder="选择标签" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">全部标签</SelectItem>
                            {mockTags.map((tag) => (
                              <SelectItem key={tag.id} value={tag.name}>
                                {tag.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      {/* 地区筛选 */}
                      <div className="w-40">
                        <Label htmlFor="region-filter">地区筛选</Label>
                        <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                          <SelectTrigger id="region-filter">
                            <SelectValue placeholder="选择地区" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">全部地区</SelectItem>
                            {mockRegions.map((region) => (
                              <SelectItem key={region.id} value={region.name}>
                                {region.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* 好友列表 */}
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <Label className="font-medium">联系人列表 ({filteredFriends.length})</Label>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={selectAllFriends}>
                            全选
                          </Button>
                          <Button variant="outline" size="sm" onClick={deselectAllFriends}>
                            取消全选
                          </Button>
                        </div>
                      </div>

                      <ScrollArea className="h-[300px] border rounded-md p-2">
                        <div className="space-y-2">
                          {filteredFriends.length > 0 ? (
                            filteredFriends.map((friend) => (
                              <div
                                key={friend.id}
                                className={`flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-md ${
                                  selectedFriends.includes(friend.id) ? "bg-blue-50" : ""
                                }`}
                              >
                                <Checkbox
                                  id={`friend-${friend.id}`}
                                  checked={selectedFriends.includes(friend.id)}
                                  onCheckedChange={() => toggleFriendSelection(friend.id)}
                                />
                                <img
                                  src={friend.avatar || "/placeholder.svg"}
                                  alt={friend.name}
                                  className="w-10 h-10 rounded-full"
                                />
                                <div className="flex-1">
                                  <div className="flex items-center">
                                    <span className="font-medium">{friend.name}</span>
                                    {friend.type === "group" && (
                                      <Badge variant="outline" className="ml-2 text-xs">
                                        群聊 · {friend.memberCount}人
                                      </Badge>
                                    )}
                                  </div>
                                  <div className="flex items-center text-sm text-gray-500">
                                    <span className="mr-2">{friend.region}</span>
                                    {friend.tags.map((tag) => (
                                      <Badge key={tag} variant="outline" className="mr-1 text-xs">
                                        {tag}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                                {friend.type === "personal" ? (
                                  <User className="h-4 w-4 text-gray-400" />
                                ) : (
                                  <Users className="h-4 w-4 text-gray-400" />
                                )}
                              </div>
                            ))
                          ) : (
                            <div className="text-center py-8 text-gray-500">没有找到匹配的联系人</div>
                          )}
                        </div>
                      </ScrollArea>

                      <div className="mt-2 text-sm text-gray-500">已选择 {selectedFriends.length} 位联系人</div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-8 text-gray-500 border rounded-md">请先选择至少一个设备</div>
              )}

              <div className="flex justify-between">
                <Button variant="outline" onClick={handlePrevious}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  上一步
                </Button>
                <Button onClick={handleSubmit}>
                  <Check className="mr-2 h-4 w-4" />
                  确认
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

