import { cn } from "@/lib/utils"

interface StepIndicatorProps {
  currentStep: number
  steps: string[]
}

export function StepIndicator({ currentStep, steps }: StepIndicatorProps) {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center">
            <div className="relative">
              <div
                className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-full border-2 text-sm font-semibold",
                  currentStep > index
                    ? "border-blue-600 bg-blue-600 text-white"
                    : currentStep === index
                      ? "border-blue-600 text-blue-600"
                      : "border-gray-300 text-gray-300",
                )}
              >
                {index + 1}
              </div>
              <span
                className={cn(
                  "absolute -bottom-6 left-1/2 w-max -translate-x-1/2 text-sm font-medium",
                  currentStep >= index ? "text-blue-600" : "text-gray-500",
                )}
              >
                {step}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div
                className={cn(
                  "h-0.5 w-full min-w-[3rem] max-w-[8rem]",
                  currentStep > index ? "bg-blue-600" : "bg-gray-300",
                )}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

