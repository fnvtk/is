"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { PlusCircle, MoreVertical, Edit, Trash2, ArrowLeft, Clock } from "lucide-react"

// 模拟数据
const mockPushTasks = [
  {
    id: "1",
    name: "618活动推广消息",
    pushTime: "2025-06-18 10:00",
    progress: 100,
    status: "已完成",
  },
  {
    id: "2",
    name: "新品上市通知",
    pushTime: "2025-03-25 09:30",
    progress: 75,
    status: "进行中",
  },
  {
    id: "3",
    name: "会员专属优惠",
    pushTime: "2025-04-01 14:00",
    progress: 0,
    status: "待执行",
  },
  {
    id: "4",
    name: "节日祝福消息",
    pushTime: "2025-05-01 08:00",
    progress: 0,
    status: "已停止",
  },
]

export default function MessagePushPage() {
  const router = useRouter()
  const [tasks, setTasks] = useState(mockPushTasks)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null)

  const handleDelete = (id: string) => {
    setTaskToDelete(id)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    if (taskToDelete) {
      setTasks(tasks.filter((task) => task.id !== taskToDelete))
      setTaskToDelete(null)
    }
    setDeleteDialogOpen(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "已完成":
        return "bg-green-500"
      case "进行中":
        return "bg-blue-500"
      case "已停止":
        return "bg-gray-500"
      default:
        return "bg-gray-300"
    }
  }

  const getStatusBadgeStyle = (status: string) => {
    switch (status) {
      case "已完成":
        return "bg-green-100 text-green-800"
      case "进行中":
        return "bg-blue-100 text-blue-800"
      case "已停止":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="container mx-auto py-6">
      {/* 顶部导航栏 */}
      <div className="flex items-center justify-between mb-6">
        <Button variant="ghost" size="icon" onClick={() => router.push("/workspace")} className="mr-auto">
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <h1 className="text-2xl font-bold absolute left-1/2 transform -translate-x-1/2">消息推送</h1>

        <Link href="/workspace/group-push/new">
          <Button className="flex items-center gap-1">
            <PlusCircle className="h-4 w-4" />
            新建推送
          </Button>
        </Link>
      </div>

      {/* 优化后的列表 - 上下分布形式 */}
      <div className="space-y-3">
        {tasks.map((task) => (
          <Card key={task.id} className="overflow-hidden hover:shadow-sm transition-shadow">
            <div className="flex">
              {/* 左侧状态标记 */}
              <div className={`w-1.5 ${getStatusColor(task.status)}`}></div>

              {/* 主要内容 */}
              <div className="flex flex-1 p-4">
                {/* 左侧信息区域 */}
                <div className="flex flex-col justify-between flex-1 mr-4">
                  {/* 任务名称 - 单独一行 */}
                  <div className="font-medium text-base mb-2 truncate">{task.name}</div>

                  {/* 中间区域 - 状态和进度 */}
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusBadgeStyle(task.status)}`}>
                      {task.status}
                    </span>

                    <div className="flex items-center gap-2 flex-1">
                      <Progress value={task.progress} className="h-2 flex-1 max-w-[120px]" />
                      <span className="text-xs text-gray-500 whitespace-nowrap">{task.progress}%</span>
                    </div>
                  </div>

                  {/* 底部 - 推送时间 */}
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {task.pushTime}
                  </div>
                </div>

                {/* 右侧操作区域 */}
                <div className="flex items-center">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <Link href={`/workspace/group-push/${task.id}/edit`}>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          编辑
                        </DropdownMenuItem>
                      </Link>
                      <DropdownMenuItem onClick={() => handleDelete(task.id)}>
                        <Trash2 className="mr-2 h-4 w-4" />
                        删除
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* 空状态 */}
      {tasks.length === 0 && (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="bg-gray-100 p-4 rounded-full mb-4">
            <Clock className="h-10 w-10 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">暂无推送任务</h3>
          <p className="text-gray-500 mb-4">点击"新建推送"按钮创建您的第一个推送任务</p>
          <Link href="/workspace/group-push/new">
            <Button>
              <PlusCircle className="h-4 w-4 mr-2" />
              新建推送
            </Button>
          </Link>
        </div>
      )}

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>确认删除</DialogTitle>
            <DialogDescription>您确定要删除这个推送任务吗？此操作无法撤销。</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

