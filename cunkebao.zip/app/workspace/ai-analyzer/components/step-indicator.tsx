import { Check } from "lucide-react"

interface Step {
  number: number
  title: string
}

interface StepIndicatorProps {
  currentStep: number
  steps: Step[]
}

export function StepIndicator({ currentStep, steps }: StepIndicatorProps) {
  return (
    <div className="flex items-center w-full">
      {steps.map((step, index) => (
        <div key={step.number} className="flex items-center flex-1">
          <div className="flex flex-col items-center">
            <div
              className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                currentStep > step.number
                  ? "bg-blue-500 border-blue-500 text-white"
                  : currentStep === step.number
                    ? "border-blue-500 text-blue-500"
                    : "border-gray-300 text-gray-300"
              }`}
            >
              {currentStep > step.number ? <Check className="w-5 h-5" /> : <span>{step.number}</span>}
            </div>
            <span
              className={`mt-2 text-sm ${currentStep >= step.number ? "text-blue-500 font-medium" : "text-gray-500"}`}
            >
              {step.title}
            </span>
          </div>

          {index < steps.length - 1 && (
            <div className={`flex-1 h-0.5 mx-2 ${currentStep > step.number ? "bg-blue-500" : "bg-gray-200"}`}></div>
          )}
        </div>
      ))}
    </div>
  )
}

